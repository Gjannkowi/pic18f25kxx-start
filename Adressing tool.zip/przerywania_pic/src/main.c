#pragma config FEXTOSC = OFF // Wyb�r trybu zewn�trznego oscylatora (oscylator wy��czony)
#pragma config WDTE = OFF    // Tryb pracy Watchdog (wy��czony)
#pragma config LVP = OFF     // Programowanie niskonapi�ciowe wy��czone
#include <xc.h>
#include <pic18f25k42.h>

// W�asne definicje rejestr�w na wypadek problem�w z plikami nag��wkowymi
#ifndef PORTA
#define PORTA (*(volatile unsigned char *)0xFCA)
#endif
#ifndef LATA
#define LATA (*(volatile unsigned char *)0xFBA)
#endif
#ifndef LATB
#define LATB (*(volatile unsigned char *)0xFBB)
#endif
#ifndef PORTB
#define PORTB (*(volatile unsigned char *)0xFCB)
#endif
#ifndef PORTC
#define PORTC (*(volatile unsigned char *)0xFCC)
#endif

#define _XTAL_FREQ 4000000UL // 4MHz zgodnie z orygina�em CCS

#ifndef OSCFRQ
#define OSCFRQ (*(volatile unsigned char *)0x39DF)
#endif
#ifndef ANSELA
#define ANSELA (*(volatile unsigned char *)0x3A40)
#endif
#ifndef ANSELB
#define ANSELB (*(volatile unsigned char *)0x3A48)
#endif
#ifndef ANSELC
#define ANSELC (*(volatile unsigned char *)0x3A50)
#endif
#ifndef ODCONA
#define ODCONA (*(volatile unsigned char *)0x3A42)
#endif
#ifndef ODCONA
#define ODCONA (*(volatile unsigned char *)0x3A42)
#endif
#ifndef ODCONB
#define ODCONB (*(volatile unsigned char *)0x3A4A)
#endif
#ifndef TRISA
#define TRISA (*(volatile unsigned char *)0x3FC2)
#endif
#ifndef TRISB
#define TRISB (*(volatile unsigned char *)0x3FC3)
#endif
#ifndef TRISC
#define TRISC (*(volatile unsigned char *)0x3FC4)
#endif
#ifndef WPUA
#define WPUA (*(volatile unsigned char *)0x3A41)
#endif
#ifndef WPUB
#define WPUB (*(volatile unsigned char *)0x3A49)
#endif
#ifndef WPUC
#define WPUC (*(volatile unsigned char *)0x3A51)
#endif

// Rejestry UART1 dla DALI
#ifndef U1CON0
#define U1CON0 (*(volatile unsigned char *)0x3AB0)
#endif
#ifndef U1CON1
#define U1CON1 (*(volatile unsigned char *)0x3AB1)
#endif
#ifndef U1CON2
#define U1CON2 (*(volatile unsigned char *)0x3AB2)
#endif
#ifndef U1BRGL
#define U1BRGL (*(volatile unsigned char *)0x3AB3)
#endif
#ifndef U1BRGH
#define U1BRGH (*(volatile unsigned char *)0x3AB4)
#endif
#ifndef U1FIFO
#define U1FIFO (*(volatile unsigned char *)0x3AB5)
#endif
#ifndef U1UIR
#define U1UIR (*(volatile unsigned char *)0x3AB6)
#endif
#ifndef U1ERRIR
#define U1ERRIR (*(volatile unsigned char *)0x3AB7)
#endif
#ifndef U1ERRIE
#define U1ERRIE (*(volatile unsigned char *)0x3AB8)
#endif
#ifndef U1RXB
#define U1RXB (*(volatile unsigned char *)0x3AC0)
#endif
#ifndef U1TXB
#define U1TXB (*(volatile unsigned char *)0x3AC1)
#endif
#ifndef U1RXBE
#define U1RXBE (*(volatile unsigned char *)0x3AC2)
#endif
#ifndef U1TXBE
#define U1TXBE (*(volatile unsigned char *)0x3AC4)
#endif
#ifndef RC6PPS
#define RC6PPS (*(volatile unsigned char *)0x3A7E)
#endif
#ifndef U1RXPPS
#define U1RXPPS (*(volatile unsigned char *)0x3AE8)
#endif
#ifndef U1P1L
#define U1P1L (*(volatile unsigned char *)0x3ABA)
#endif
#ifndef U1P1H
#define U1P1H (*(volatile unsigned char *)0x3ABB)
#endif
#ifndef U1P2L
#define U1P2L (*(volatile unsigned char *)0x3ABC)
#endif
#ifndef U1P2H
#define U1P2H (*(volatile unsigned char *)0x3ABD)
#endif

// Rejestry Timer1 dla timeout
#ifndef T1CON
#define T1CON (*(volatile unsigned char *)0x39CF)
#endif
#ifndef T1CLK
#define T1CLK (*(volatile unsigned char *)0x39D0)
#endif
#ifndef TMR1H
#define TMR1H (*(volatile unsigned char *)0x39D2)
#endif
#ifndef TMR1L
#define TMR1L (*(volatile unsigned char *)0x39D1)
#endif
#ifndef PIR3
#define PIR3 (*(volatile unsigned char *)0x39A3)
#endif
#ifndef PIE3
#define PIE3 (*(volatile unsigned char *)0x39B3)
#endif
#ifndef INTCON
#define INTCON (*(volatile unsigned char *)0x3FD2)
#endif
#ifndef CLKRCLK
#define CLKRCLK (*(volatile unsigned char *)0x39C5)
#endif

// Rejestry przerwa�
#ifndef PIR4
#define PIR4 (*(volatile unsigned char *)0x39A4)
#endif
#ifndef PIE4
#define PIE4 (*(volatile unsigned char *)0x39B4)
#endif
#ifndef U1UIR
#define U1UIR (*(volatile unsigned char *)0x3AB6)
#endif
#ifndef U1IE
#define U1IE (*(volatile unsigned char *)0x3AB9)
#endif
#ifndef PIR7
#define PIR7 (*(volatile unsigned char *)0x39A7)
#endif
#ifndef PIE7
#define PIE7 (*(volatile unsigned char *)0x39B7)
#endif
#ifndef INTCON0
#define INTCON0 (*(volatile unsigned char *)0x3FD2)
#endif

// Struktura bitowa dla PORTA
struct
{
    unsigned char LED1 : 1; // RA0 - CZERWONY: B��dny Adr >63
    unsigned char LED2 : 1; // RA1 - �ӣTY: START po��czenia
    unsigned char LED3 : 1; // RA2 - ZIELONY: Online
    unsigned char LED4 : 1; // RA3 - CZERWONY: Start adresowania
    unsigned char LED5 : 1; // RA4 - �ӣTY: Adres ok
    unsigned char LED6 : 1; // RA5 - ZIELONY: NIEPOWODZENIE
    unsigned char SW2 : 1;  // RA6 - Przycisk 2
    unsigned char SW1 : 1;  // RA7 - Przycisk 1
} RB_A;

// ============== ZMIENNE GLOBALNE ==============
// Bufory UART
#define RX_BUFFER_SIZE 32
#define TX_BUFFER_SIZE 32

volatile unsigned char rx_buffer[RX_BUFFER_SIZE];
volatile unsigned char rx_head = 0;
volatile unsigned char rx_tail = 0;

volatile unsigned char tx_buffer[TX_BUFFER_SIZE];
volatile unsigned char tx_head = 0;
volatile unsigned char tx_tail = 0;

volatile unsigned char uart_rx_flag = 0;
volatile unsigned char uart_tx_ready = 1;

// Timer1 - flaga 100ms
volatile unsigned char timer1_flag = 0;
volatile unsigned char timer1_counter = 0;

// Zmienne DALI
unsigned char state_counter = 0; // Licznik dla op�nie� w stanach (100ms * state_counter)
volatile unsigned char bBlink = 0;
volatile unsigned char bDALI_Adr = 0;
unsigned char ErrCode = 0;

// Debouncing przycisk�w
unsigned char sw1_pressed = 0;
unsigned char sw2_pressed = 0;

// Zmienne pomocnicze dla stan�w
unsigned char check_adr_phase = 0; // Faza sprawdzania adresu (0=czekaj, 1=wy�lij, 2=odbierz)
unsigned char dim_step = 0;        // Krok �ciemniania (0-6)

volatile unsigned char xDALI_RX_OK = 0;   // Status odbioru RX (1=OK)
volatile unsigned char bDALI_RX_Dat = 0;  // Dane odebrane z DALI
volatile unsigned char bDALI_RX_Wait = 0; // Timeout odbioru DALI
unsigned char param_cnt = 0;              // Licznik sekwencji logowania

// Zmienne dla asynchronicznej obs�ugi stan�w (bez delay_ms)
volatile unsigned char tx_in_progress = 0; // Flaga transmisji w toku
volatile unsigned char wait_counter = 0;   // Licznik oczekiwania w bie��cym stanie

// ============== DEFINICJE KOMEND DALI ==============
#define D_SPECIAL_STORE_DTR0 0xA3
#define D_BROADCAST_ADDRESS 0xFF
#define D_DAP_ADDRESS 0xFE
#define D_STORE_DTR_AS_SHORT_ADDRESS 0x80
#define D_QUERY_STATUS 0x90 // Zg�o� stan do mastera
#define D_QUERY_CONTENT_DTR 0x98
#define D_OFF 0x00              // Lampa natychmiast wy��czona
#define D_RECALL_MAX_LEVEL 0x05 // Wywo�aj poziom max
#define D_RECALL_MIN_LEVEL 0x06
#define D_QUERY_ACTUAL_LEVEL 0xA0

// ============== DEFINICJE DANYCH DALI ==============
#define K_DALI_MIN_LEVEL 144 // 144 -> 5% PWM
#define K_DALI_MAX_LEVEL 254

// Sekwencja logowania PARAM
const char K_param[5] = {'P', 'A', 'R', 'A', 'M'};

// Stany programu
enum StateEnum
{
    STANDBY,
    S66_ON,
    SEND_LOGIN,
    WAIT_NEXT,
    SEND_ADR,
    SEND_STORE,
    SHOW_RESULT, // Pokazywanie wyniku
    CHECK_ADR,   // Sprawdzanie adresu
    DIM_TEST     // Oczekiwanie ko�cowe
};

volatile enum StateEnum prg_state = STANDBY;

// ============== FUNKCJA OBS�UGI PRZERWA� ==============
// XC8 v3.10 - obs�uga Timer1 i UART1 RX
void __interrupt(irq(TMR1, U1RX), high_priority) ISR_High(void)
{
    // Przerwanie Timer1 - PIERWSZE�STWO (najwa�niejsze)
    // PIR4 bit 0 = TMR1IF, PIE4 bit 0 = TMR1IE (zgodnie z dokumentacj� K42)
    if ((PIR4 & 0x01) && (PIE4 & 0x01))
    {
        // Prze�aduj timer dla nast�pnego cyklu 100ms
        // 65536 - 12500 = 53036 = 0xCF2C
        TMR1H = 0xCF;
        TMR1L = 0x2C;

        timer1_flag = 1;
        timer1_counter++;

        // Wyczy�� flag� TMR1IF (bit 0 w PIR4)
        PIR4 &= ~0x01;
    }

    // Przerwanie UART1 RX
    // PIR7 bit 4 = U1IF (UART1 Interrupt Flag - ��czy wszystkie przerwania UART)
    // PIE7 bit 4 = U1IE (UART1 Interrupt Enable do CPU)
    // U1UIR zawiera r�ne flagi: bit 7=RXFOIF, 6=RXBFIF, 5=FERIF, 4=TXCIF, 3=RXFOIF, 2=ABDOVF, 1=PERIF, 0=CERIF
    if ((PIR7 & 0x10) && (PIE7 & 0x10)) // U1IF i U1IE (bit 4)
    {
        unsigned char uir_flags = U1UIR;

        // Sprawd� RX Buffer Full (bit 6)
        if (uir_flags & 0x40) // RXBFIF
        {
            // Odczytaj dane z bufora UART
            unsigned char data = U1RXB;

            // Dodaj do bufora cyklicznego
            unsigned char next_head = (rx_head + 1) % RX_BUFFER_SIZE;
            if (next_head != rx_tail) // Je�li bufor nie pe�ny
            {
                rx_buffer[rx_head] = data;
                rx_head = next_head;
                uart_rx_flag = 1;
            }

            // WA�NE: Upewnij si� �e przerwanie RXBFIE jest w��czone
            U1IE |= 0x40; // W��cz RXBFIE (bit 6)
        }

        // Sprawd� TX Complete (bit 4) - w trybie DALI to mo�e by� RX!
        if (uir_flags & 0x10) // TXCIF (Transmit Complete)
        {
            // W trybie DALI po zako�czeniu TX mo�e by� odebrana odpowied�
            // Sprawd� bezpo�rednio U1RXBE (bit 0 = 0 oznacza dane dost�pne)
            if (!(U1RXBE & 0x01)) // Dane dost�pne w RXBE
            {
                unsigned char data = U1RXB;
                unsigned char next_head = (rx_head + 1) % RX_BUFFER_SIZE;
                if (next_head != rx_tail)
                {
                    rx_buffer[rx_head] = data;
                    rx_head = next_head;
                    uart_rx_flag = 1;
                }
            }
        }

        // DODATKOWE: Sprawd� bezpo�rednio czy w buforze RX s� dane (nawet je�li flaga nie podniesiona)
        // W trybie DALI dane mog� pojawi� si� szybko i by� przeoczone
        while (!(U1RXBE & 0x01)) // Dop�ki s� dane w buforze (bit 0 = 0)
        {
            unsigned char data = U1RXB;
            unsigned char next_head = (rx_head + 1) % RX_BUFFER_SIZE;
            if (next_head != rx_tail)
            {
                rx_buffer[rx_head] = data;
                rx_head = next_head;
                uart_rx_flag = 1;
            }
            else
                break; // Bufor pe�ny
        }

        // Wyczy�� wszystkie flagi UART
        U1UIR = 0x00;

        // Wyczy�� g��wn� flag� U1IF w PIR7
        PIR7 &= ~0x10;
    }

    // Przerwanie UART1 TX
    // PIR4 bit 7 = U1TXIF, PIE4 bit 7 = U1TXIE
    if ((PIR4 & 0x80) && (PIE4 & 0x80))
    {
        if (tx_head != tx_tail) // Je�li s� dane do wys�ania
        {
            U1TXB = tx_buffer[tx_tail];
            tx_tail = (tx_tail + 1) % TX_BUFFER_SIZE;
            uart_tx_ready = 0;
        }
        else
        {
            PIE4 &= ~0x80; // Wy��cz przerwanie TX (bit 7)
            uart_tx_ready = 1;
        }

        // Wyczy�� flag� U1TXIF (bit 7)
        PIR4 &= ~0x80;
    }
}

// ============== FUNKCJE UART ==============
// Sprawd� czy s� dane w buforze RX
unsigned char UART_DataAvailable(void)
{
    return (rx_head != rx_tail);
}

// Odczytaj bajt z bufora RX
unsigned char UART_ReadByte(void)
{
    if (rx_head == rx_tail)
        return 0; // Brak danych

    unsigned char data = rx_buffer[rx_tail];
    rx_tail = (rx_tail + 1) % RX_BUFFER_SIZE;

    return data;
}

// Wy�lij ramk� DALI (2 bajty) - blokuj�co jak w oryginalnym FW
void UART_SendDALI(unsigned char addr, unsigned char cmd)
{
    // WA�NE: Wyczy�� bufory RX PRZED wys�aniem (usu� stare dane)
    U1FIFO |= 0x02;    // Wyczy�� sprz�towy bufor UART RX (bit 1 = RXBE)
    rx_head = rx_tail; // Wyczy�� bufor programowy

    // WA�NE: Przerwania RX musz� by� W��CZONE przez ca�y czas!
    // Nie wy��czamy przerwa� podczas transmisji - odpowied� mo�e przyj�� bardzo szybko
    U1IE |= 0x40; // Upewnij si� �e RXBFIE jest w��czone (bit 6)

    // Wy�lij adres + komend� back-to-back (DALI = 16 bit�w)
    U1TXB = addr;
    U1TXB = cmd;

    // Poczekaj a� ramka opu�ci magistral� (bit TXMTIF)
    while (!(U1ERRIR & 0x80))
        ;

    // Kr�tkie op�nienie - odpowied� mo�e przyj�� w tym czasie do bufora przez przerwania
    __delay_ms(10);
}

// ============== INICJALIZACJA ==============
void Init_UART(void)
{
    // Konfiguracja UART1 dla DALI (1200 baud, Manchester)
    U1CON0 = 0x38; // Tx+Rx w��czone, tryb DALI

    // P�okresy bitu bezczynno�ci
    U1P1H = 0x00;
    U1P1L = 0x16; // 22 p�okresy
    U1P2H = 0x00;
    U1P2L = 0x16; // 22 p�okresy

    // Baud rate dla 1200 baud przy 4MHz
    U1BRGH = 0x00;
    U1BRGL = 0xCB;

    // Polaryzacja i bity stopu
    U1CON2 = 0x64; // Odwr�cona polaryzacja, 2 bity stopu

    // Mapowanie pin�w - RC6=TX (pin 14), RC7=RX (pin 15)
    RC6PPS = 0x13;  // RC6 -> UART1 TX
    U1RXPPS = 0x17; // RC7 -> UART1 RX

    // W��cz UART
    U1CON1 = 0x80;

    // Konfiguracja przerwa� UART (u�ywamy U1UIR/U1IE, NIE PIR4/PIE4!)
    U1UIR = 0x00; // Wyczy�� wszystkie flagi przerwa� UART
    U1IE = 0x50;  // W��cz RXBFIE (bit 6) + TXCIE (bit 4 = Transmit Complete Interrupt) dla DALI RX
}

void Init_Timer1(void)
{
    // Wy��cz Timer1
    T1CON = 0x00;

    // Wyczy�� flag� TMR1IF (bit 0 w PIR4 dla PIC18F25K42)
    PIR4 &= ~0x01;

    // Warto�� pocz�tkowa dla ~100ms przy FOSC/4, prescaler 1:8
    // 4MHz/4/8 = 125kHz, 12500 tick�w = 100ms
    // 65536 - 12500 = 53036 = 0xCF2C
    TMR1H = 0xCF;
    TMR1L = 0x2C;

    // Konfiguracja Timer1
    T1CLK = 0x01;       // FOSC/4 jako �r�d�o
    T1CON = 0b00110001; // Prescaler 1:8, Timer ON

    timer1_flag = 0;
    timer1_counter = 0;

    // WA�NE: NIE w��czaj PIE3 tutaj!
    // Przerwania w��czamy DOPIERO w Init_Interrupts()
}

void Init_GPIO(void)
{
    // Wy��cz wej�cia analogowe
    ANSELA = 0x00;
    ANSELB = 0x00;
    ANSELC = 0x00;

    // Wy��cz open-drain
    ODCONA = 0x00;
    ODCONB = 0x00;

    // Kierunek port�w
    TRISA = 0b11000000; // RA0-RA5=OUT (LED), RA6-RA7=IN (przyciski)
    TRISB = 0b00001111; // RB5=OUT (przeka�nik), RB0-RB3=IN (adres)
    TRISC = 0b10001111; // RC7=IN (RX), RC6=OUT (TX), RC0-RC3=IN (adres)

    // Pull-up dla przycisk�w i prze��cznik�w
    WPUA = 0xC0; // RA6-RA7
    WPUB = 0x0F; // RB0-RB3
    WPUC = 0x0F; // RC0-RC3

    // Stan pocz�tkowy
    LATA = 0x00; // LED wy��czone
    LATB = 0x00; // Przeka�nik wy��czony
}

void Init_Interrupts(void)
{
    // XC8 v3.10: Poprawna kolejno�� inicjalizacji

    // 1. Wyczy�� wszystkie flagi przerwa�
    PIR4 = 0x00;
    PIR7 = 0x00; // Wyczy�� flag� U1IF

    // 2. Skonfiguruj INTCON0 (wy��cz priority)
    INTCON0 = 0x00; // IPEN=0, GIE=0, PEIE=0

    // 3. W��cz przerwania peryferi�w PRZED GIE
    PIE4 = 0x00;
    PIE4 |= 0x01; // TMR1IE w��czone (bit 0)

    PIE7 = 0x00;
    PIE7 |= 0x10; // U1IE w��czone (bit 4) - przerwanie UART1 do CPU

    // 4. DOPIERO TERAZ w��cz GIE i PEIE
    INTCON0 = 0xC0; // GIE=1 (bit 7) + PEIE=1 (bit 6) - Global + Peripheral Interrupt Enable

    // Testuj czy przerwania dzia�aj�
    // LED4 powinien zacz�� mruga� co 100ms
}

// ============== FUNKCJA G��WNA ==============
void main(void)
{
    // Konfiguracja oscylatora na 4MHz
    OSCFRQ = 0b00000010;  // 4 MHz HFINTOSC
    CLKRCLK = 0b00000001; // HFINTOSC dla peryferi�w

    // Inicjalizacja peryferi�w
    Init_GPIO();
    Init_UART();
    Init_Timer1();
    Init_Interrupts();

    // Test LED - wszystkie na 1 sekund�
    LATA = 0x3F;
    for (unsigned char i = 0; i < 40; i++) // 40 x 25ms = 1s
    {
        __delay_ms(25);
    }
    LATA = 0x00;
    __delay_ms(200);

    // P�tla g��wna - maszyna stan�w DALI (w pe�ni asynchroniczna, obs�ugiwana przez przerwania)
    while (1)
    {
        // Obs�uga timera co 100ms
        if (timer1_flag)
        {
            timer1_flag = 0;

            // Migacz LED 1s (10 x 100ms)
            if (++bBlink >= 10)
                bBlink = 0;

            // Pobierz i sprawd� adres z prze��cznik�w obrotowych
            bDALI_Adr = ((PORTC & 0x0F) ^ 0x0F) * 10 + ((PORTB & 0x0F) ^ 0x0F);

            if (bDALI_Adr > 63) // >63 = nieprawid�owy = Reset
            {
                LATA &= 0xC0;   // Wszystkie LED WY�
                if (bBlink < 5) // 0.5s ON / 0.5s OFF
                {
                    LATA |= 0x01; // LED1 (CZERWONY) Miga: Adr >63
                }
                LATB &= ~(1 << 5);   // RB5: Przeka�nik/S66 WY�
                prg_state = STANDBY; // Reset
                wait_counter = 0;
                state_counter = 0;
            }
            else // W�a�ciwy przebieg programu - tylko gdy adres OK
            {
                // W�a�ciwy przebieg programu
                switch (prg_state)
                {
                case STANDBY:          // ## Krok 1: Stan bezczynno�ci
                    LATB &= ~(1 << 5); // RB5: Przeka�nik/S66 WY�
                    LATA &= 0xC0;      // Wszystkie LED WY�
                    if (bBlink == 1)   // Kr�tkie b�y�ni�cie
                    {
                        LATA |= 0x02; // LED2 (�ӣTY) b�yska = Bezczynno��
                    }
                    bDALI_RX_Wait = 0; // Inicjalizacja TimeOut DALI
                    param_cnt = 0;
                    xDALI_RX_OK = 0; // Reset flagi odbioru
                    bDALI_RX_Dat = 0;
                    state_counter = 0; // Reset licznika stanu
                    wait_counter = 0;
                    dim_step = 0;
                    check_adr_phase = 0;

                    // Sprawd� przycisk 1 (aktywny niski - RA7)
                    if (!(PORTA & 0x80)) // Bit 7 = 0 (LOW) = wci�ni�ty
                    {
                        if (!sw1_pressed) // Tylko raz na naci�ni�cie
                        {
                            sw1_pressed = 1;
                            wait_counter = 0;
                            prg_state = S66_ON;
                        }
                    }
                    else
                    {
                        sw1_pressed = 0; // Reset po zwolnieniu
                    }

                    // Sprawd� przycisk 2 (aktywny niski - RA6)
                    if (!(PORTA & 0x40)) // Bit 6 = 0 (LOW) = wci�ni�ty
                    {
                        if (!sw2_pressed) // Tylko raz na naci�ni�cie
                        {
                            sw2_pressed = 1;
                            wait_counter = 0;
                            check_adr_phase = 0;
                            prg_state = CHECK_ADR;
                        }
                    }
                    else
                    {
                        sw2_pressed = 0; // Reset po zwolnieniu
                    }
                    break;

                case S66_ON:          // ## Krok 2: Przycisk 1 naci�ni�ty - czekaj a� S66 gotowe
                    LATA &= 0xC0;     // Wszystkie LED WY�
                    LATB |= (1 << 5); // RB5: Przeka�nik/S66 W�

                    // Czekaj 10 cykli (1000ms) a� S66 gotowe
                    if (++wait_counter >= 10)
                    {
                        wait_counter = 0;
                        param_cnt = 0;     // Reset licznika PARAM
                        xDALI_RX_OK = 0;   // Reset flagi odbioru
                        bDALI_RX_Dat = 0;  // Reset danych
                        bDALI_RX_Wait = 0; // Reset timeoutu
                        prg_state = SEND_LOGIN;
                    }
                    break;

                case SEND_LOGIN:       // ## Krok 3: Po��cz S66 w tryb parametryzacji
                    if (param_cnt < 5) // Wy�lij 5 znak�w P,A,R,A,M (1 znak na 100ms)
                    {
                        LATA ^= 0x02; // LED2 (�ӣTY) prze��cz (miga)
                        UART_SendDALI(D_DAP_ADDRESS, K_param[param_cnt]);
                        param_cnt++;
                        break;
                    }

                    // Po wys�aniu wszystkich 5 znak�w, wy�lij QUERY_STATUS
                    if (param_cnt == 5)
                    {
                        UART_SendDALI(D_BROADCAST_ADDRESS, D_QUERY_STATUS);
                        param_cnt = 6; // Oznacz �e wys�ali�my query
                        bDALI_RX_Wait = 0;
                        break;
                    }

                    // Sprawd� czy s� dane w buforze (przerwania ju� odebra�y)
                    if (UART_DataAvailable())
                    {
                        bDALI_RX_Dat = UART_ReadByte();
                        xDALI_RX_OK = 1;
                    }

                    // Sprawd� czy lampa odpowiedzia�a
                    if (xDALI_RX_OK)
                    {
                        ErrCode = 0; // Login OK
                        xDALI_RX_OK = 0;
                        bDALI_RX_Dat = 0;
                        state_counter = 0;
                        bDALI_RX_Wait = 0;
                        wait_counter = 0;
                        prg_state = SEND_ADR; // Id� dalej do wysy�ania adresu
                    }
                    else if (bDALI_RX_Wait > 15) // Timeout 1.5s (15 x 100ms)
                    {
                        ErrCode = 1; // Brak odpowiedzi - b��d
                        state_counter = 0;
                        bDALI_RX_Wait = 0;
                        wait_counter = 0;
                        prg_state = WAIT_NEXT; // Poka� b��d
                    }
                    else if (param_cnt == 6)
                    {
                        bDALI_RX_Wait++;
                    }
                    break;

                case WAIT_NEXT:       // ## Krok 4: Pokazanie b��du przez 2s
                    LATB |= (1 << 5); // RB5: Przeka�nik/S66 W� (utrzymaj)
                    LATA &= 0xC0;     // Wszystkie LED WY�
                    LATA |= 0x01;     // LED1 (CZERWONY) W� = B��d loginu

                    if (++wait_counter >= 20) // 20 cykli x 100ms = 2 sekundy
                    {
                        wait_counter = 0;
                        LATB &= ~(1 << 5);   // RB5: Przeka�nik WY�
                        prg_state = STANDBY; // Wr�� do STANDBY
                    }
                    break;

                case SEND_ADR: // ## Krok 5: Wy�lij nowy Adr do DTR0
                    if (wait_counter == 0)
                    {
                        LATA &= 0xC0; // Wszystkie LED WY�
                        LATA |= 0x02; // LED2 (�ӣTY) W�: Wysy�anie adresu

                        xDALI_RX_OK = 0;
                        bDALI_RX_Dat = 0;

                        UART_SendDALI(D_SPECIAL_STORE_DTR0, bDALI_Adr);
                        wait_counter = 1;
                    }
                    else if (wait_counter >= 2) // Czekaj 200ms (2 x 100ms)
                    {
                        wait_counter = 0;
                        state_counter = 0;
                        bDALI_RX_Wait = 0;
                        prg_state = SEND_STORE;
                    }
                    else
                    {
                        wait_counter++;
                    }
                    break;

                case SEND_STORE: // ## Krok 6: Wy�lij polecenie zapisu (2x!)
                    if (wait_counter == 0)
                    {
                        LATA &= 0xC0; // Wszystkie LED WY�
                        LATA |= 0x02; // LED2 (�ӣTY) W�: Zapisywanie

                        xDALI_RX_OK = 0;
                        bDALI_RX_Dat = 0;

                        // Wy�lij komend� pierwszy raz
                        UART_SendDALI(D_BROADCAST_ADDRESS, D_STORE_DTR_AS_SHORT_ADDRESS);
                        wait_counter = 1;
                    }
                    else if (wait_counter == 1) // Czekaj 100ms
                    {
                        wait_counter++;
                    }
                    else if (wait_counter == 2) // Wy�lij drugi raz
                    {
                        UART_SendDALI(D_BROADCAST_ADDRESS, D_STORE_DTR_AS_SHORT_ADDRESS);
                        wait_counter++;
                    }
                    else if (wait_counter < 5) // Czekaj 200ms (2 x 100ms)
                    {
                        wait_counter++;
                    }
                    else // Przejd� do pokazywania wyniku
                    {
                        wait_counter = 0;
                        state_counter = 0;
                        prg_state = SHOW_RESULT;
                    }
                    break;

                case SHOW_RESULT: // ## Krok 6b: Pokazywanie wyniku przez 2s
                    LATA &= 0xC0;
                    LATA |= 0x04; // LED3 (ZIELONY) W�: Zapis OK

                    if (++wait_counter >= 20) // 20 cykli x 100ms = 2 sekundy
                    {
                        wait_counter = 0;
                        state_counter = 0;
                        LATB &= ~(1 << 5); // Wy��cz przeka�nik

                        // Czekaj jeszcze 10 cykli (1s) na roz�adowanie
                        prg_state = DIM_TEST; // U�yj DIM_TEST jako stan oczekiwania
                        dim_step = 0;
                    }
                    break;

                case CHECK_ADR: // ## Krok 7: Sprawd� adres przez QUERY_ACTUAL_LEVEL
                    switch (check_adr_phase)
                    {
                    case 0:               // Faza 1: W��cz S66 i czekaj 1s
                        LATA &= 0xC0;     // Wszystkie LED WY�
                        LATB |= (1 << 5); // RB5: Przeka�nik/S66 W�
                        LATA |= 0x10;     // LED5 (�ӣTY) W�: Sprawdzanie Adr trwa...

                        if (++wait_counter >= 10) // Czekaj 1000ms
                        {
                            wait_counter = 0;
                            check_adr_phase = 1;
                        }
                        break;

                    case 1: // Faza 2: Wy�lij query (bufor ju� czyszczony w UART_SendDALI)
                        bDALI_RX_Dat = 0;
                        xDALI_RX_OK = 0;

                        UART_SendDALI((unsigned char)((bDALI_Adr << 1) | 1), D_QUERY_ACTUAL_LEVEL);

                        check_adr_phase = 2;
                        wait_counter = 0;
                        break;

                    case 2:                      // Faza 2b: Czekaj 500ms po wys�aniu na odpowied�
                        if (++wait_counter >= 5) // 5 cykli = 500ms
                        {
                            wait_counter = 0;
                            check_adr_phase = 3;
                        }
                        break;

                    case 3: // Faza 3: Czekaj na odpowied�, sprawdzaj CZʌCIEJ (co 100ms przez 1.5s)
                        // LED5 �wieci - sprawdzanie w toku (nie migaj)
                        LATA |= 0x10; // LED5 �wieci podczas sprawdzania

                        // BEZPO�REDNIO sprawd� sprz�towy bufor RX (jak w oryginalnym kodzie)
                        // U1RXBE bit 0 = 0 oznacza dane dost�pne
                        if (!xDALI_RX_OK && !(U1RXBE & 0x01))
                        {
                            unsigned char rx_data = U1RXB; // Odczytaj ze sprz�towego bufora

                            // Filtruj echo - ignoruj 0xA0 (komend�) i sprawdzone warto�ci
                            // Lampa odpowiada 0-254, ale prawie nigdy dok�adnie 0xA0
                            if (rx_data != 0xA0 && rx_data <= 254)
                            {
                                bDALI_RX_Dat = rx_data;
                                xDALI_RX_OK = 1;
                            }
                        }

                        if (xDALI_RX_OK || wait_counter >= 15) // Otrzymano odpowied� LUB timeout (1500ms)
                        {
                            LATA &= ~0x10; // Wy��cz LED5

                            if (xDALI_RX_OK) // Lampa odpowiedzia�a - OK, zapal LED6 i �ciemniaj
                            {
                                LATA |= 0x20;        // LED6 (ZIELONY) W� = Jest odpowied�
                                check_adr_phase = 4; // Przejd� do �ciemniania
                                wait_counter = 0;
                                dim_step = 0;
                            }
                            else // Timeout - brak odpowiedzi, zapal LED4
                            {
                                LATA |= 0x08;         // LED4 (CZERWONY) W� = Brak odpowiedzi
                                check_adr_phase = 10; // Przejd� do zako�czenia z b��dem
                                wait_counter = 0;
                            }
                        }
                        else
                        {
                            wait_counter++;
                        }
                        break;

                    case 4: // Faza 4: �ciemnianie (6 krok�w po 300ms = 3 cykle ka�dy)
                        switch (dim_step)
                        {
                        case 0: // 100% - 254
                            if (wait_counter == 0)
                            {
                                UART_SendDALI((unsigned char)(bDALI_Adr << 1), K_DALI_MAX_LEVEL);
                            }
                            if (++wait_counter >= 3)
                            {
                                wait_counter = 0;
                                dim_step++;
                            }
                            break;
                        case 1: // 75% - 243
                            if (wait_counter == 0)
                            {
                                UART_SendDALI((unsigned char)(bDALI_Adr << 1), 243);
                            }
                            if (++wait_counter >= 3)
                            {
                                wait_counter = 0;
                                dim_step++;
                            }
                            break;
                        case 2: // 50% - 230
                            if (wait_counter == 0)
                            {
                                UART_SendDALI((unsigned char)(bDALI_Adr << 1), 230);
                            }
                            if (++wait_counter >= 3)
                            {
                                wait_counter = 0;
                                dim_step++;
                            }
                            break;
                        case 3: // 25% - 203
                            if (wait_counter == 0)
                            {
                                UART_SendDALI((unsigned char)(bDALI_Adr << 1), 203);
                            }
                            if (++wait_counter >= 3)
                            {
                                wait_counter = 0;
                                dim_step++;
                            }
                            break;
                        case 4: // 10% - 180
                            if (wait_counter == 0)
                            {
                                UART_SendDALI((unsigned char)(bDALI_Adr << 1), 180);
                            }
                            if (++wait_counter >= 3)
                            {
                                wait_counter = 0;
                                dim_step++;
                            }
                            break;
                        case 5: // 5% - 144, czekaj 1000ms = 10 cykli
                            if (wait_counter == 0)
                            {
                                UART_SendDALI((unsigned char)(bDALI_Adr << 1), K_DALI_MIN_LEVEL);
                            }
                            if (++wait_counter >= 10)
                            {
                                wait_counter = 0;
                                dim_step++;
                            }
                            break;
                        case 6:                   // Zako�cz �ciemnianie
                            check_adr_phase = 10; // Przejd� do zako�czenia
                            wait_counter = 0;
                            break;
                        }
                        break;

                    case 10:               // Faza 5: Zako�czenie - wy��cz przeka�nik i czekaj 1s
                        LATB &= ~(1 << 5); // Wy��cz przeka�nik

                        if (++wait_counter >= 10) // Czekaj 1000ms
                        {
                            wait_counter = 0;
                            state_counter = 0;
                            check_adr_phase = 0;
                            prg_state = STANDBY;
                        }
                        break;
                    }
                    break;

                case DIM_TEST:                // Stan oczekiwania po SHOW_RESULT
                    if (++wait_counter >= 10) // Czekaj 1s na roz�adowanie elektroniki
                    {
                        wait_counter = 0;
                        LATA &= 0xC0; // Wy��cz wszystkie LED
                        prg_state = STANDBY;
                    }
                    break;

                default:          // Nieznany Case
                    LATA |= 0x01; // LED1 (CZERWONY) W�
                    prg_state = STANDBY;
                    break;
                }

                // Wyczy�� ewentualne �mieci z bufora DALI (jak w oryginale)
                // UWAGA: Nie czy�ci� je�li stan aktywnie czeka na odpowied�!
                if (prg_state == STANDBY || prg_state == S66_ON)
                {
                    xDALI_RX_OK = 0;
                    bDALI_RX_Dat = 0;
                }
                // WA�NE: W CHECK_ADR NIE zeruj xDALI_RX_OK - czekamy na odpowied�!
            } // Koniec else (w�a�ciwy przebieg)

        } // Koniec if (timer1_flag)
    } // Koniec while(1)
} // Koniec main()
